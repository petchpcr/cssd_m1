package com.poseintelligence.cssdm1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class dialog_check_usage_count extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_check_usage_count);
    }
}