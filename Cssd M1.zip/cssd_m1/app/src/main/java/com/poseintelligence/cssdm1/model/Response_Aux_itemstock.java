package com.poseintelligence.cssdm1.model;

/**
 * Created by Tanadech on 12/18/2016.
 */

public class Response_Aux_itemstock {
    private Boolean error;
    private String xFields1;
    private String xFields2;
    private String xFields3;
    private String xFields4;
    private String xFields5;
    private String xFields6;
    private String xFields7;
    private String xFields8;
    private String xFields9;
    private String xFields10;
    private String xFields11;
    private String xFields12;
    private String xFields13;
    private String xFields14;
    private String xFields15;
    private String xFields16;
    private boolean Is_Check;

    public Boolean getError() {
        return error;
    }
    public void setError(Boolean error) {
        this.error = error;
    }

    public String getFields1() { return xFields1; }
    public void setFields1(String xFields1) {
        this.xFields1 = xFields1;
    }

    public String getFields2() { return xFields2; }
    public void setFields2(String xFields2) {
        this.xFields2 = xFields2;
    }

    public String getFields3() { return xFields3; }
    public void setFields3(String xFields3) {
        this.xFields3 = xFields3;
    }

    public String getFields4() { return xFields4; }
    public void setFields4(String xFields4) {
        this.xFields4 = xFields4;
    }

    public String getFields5() { return xFields5; }
    public void setFields5(String xFields5) {
        this.xFields5 = xFields5;
    }

    public String getFields6() { return xFields6; }
    public void setFields6(String xFields6) {
        this.xFields6 = xFields6;
    }

    public String getFields7() { return xFields7; }
    public void setFields7(String xFields7) {
        this.xFields7 = xFields7;
    }

    public String getFields8() { return xFields8; }
    public void setFields8(String xFields8) {
        this.xFields8 = xFields8;
    }

    public String getFields9() { return xFields9; }
    public void setFields9(String xFields9) {
        this.xFields9 = xFields9;
    }

    public String getxFields10() {
        return xFields10;
    }

    public void setxFields10(String xFields10) {
        this.xFields10 = xFields10;
    }

    public String getxFields11() {
        return xFields11;
    }

    public void setxFields11(String xFields11) {
        this.xFields11 = xFields11;
    }

    public String getxFields12() {
        return xFields12;
    }

    public void setxFields12(String xFields12) {
        this.xFields12 = xFields12;
    }

    public String getxFields13() {
        return xFields13;
    }

    public void setxFields13(String xFields13) {
        this.xFields13 = xFields13;
    }

    public String getxFields14() {
        return xFields14;
    }

    public void setxFields14(String xFields14) {
        this.xFields14 = xFields14;
    }

    public String getxFields15() {
        return xFields15;
    }

    public void setxFields15(String xFields15) {
        this.xFields15 = xFields15;
    }

    public String getxFields16() {
        return xFields16;
    }

    public void setxFields16(String xFields16) {
        this.xFields16 = xFields16;
    }

    public boolean isIs_Check() {
        return Is_Check;
    }

    public void setIs_Check(boolean is_Check) {
        Is_Check = is_Check;
    }

}
