package com.poseintelligence.cssdm1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.models.SlideModel;

import java.util.ArrayList;
import java.util.List;

public class dialog_pic_RemarkActivity extends Activity {

    ImageSlider imageslide;
    TextView text_remark;
    ImageView images;
    String codeData_pic1;
    String Picture,Picture2,Picture3,Pic_Type,Pictruetext,NameType,Note;

    String Url = ((CssdProject) getApplication()).getxUrl();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_pic_remark);

        byIntent();

        init();
    }

    private void byIntent(){
        Intent intent = getIntent();
        Picture = intent.getStringExtra("Picture");
        Picture2 = intent.getStringExtra("Picture2");
        Picture3 = intent.getStringExtra("Picture3");
        Pictruetext = intent.getStringExtra("Pictruetext");
        Pic_Type = intent.getStringExtra("Pic_Type");
        NameType = intent.getStringExtra("NameType");
        Note = intent.getStringExtra("Note");
    }

    public void init() {
        imageslide = (ImageSlider) findViewById(R.id.imageslide);
        text_remark = (TextView) findViewById(R.id.text_remark);
        if (Note.equals("")){
            text_remark.setText(NameType);
        }else {
            text_remark.setText(NameType+"("+Note+")");
        }
        images = (ImageView) findViewById(R.id.images);
        if (Pic_Type.equals("0")){
            images.setVisibility(View.VISIBLE);
            imageslide.setVisibility(View.GONE);
            Log.d("DJGJDGVJ",Pictruetext);
            codeData_pic1 = "data:image/jpeg;base64,"+Pictruetext;
            codeData_pic1 = codeData_pic1.replace("data:image/jpeg;base64,","");
            byte[] code_pic1 = Base64.decode(codeData_pic1,Base64.DEFAULT);
            Bitmap bitmap_pic1 = BitmapFactory.decodeByteArray(code_pic1,0,code_pic1.length);
            images.setImageBitmap(bitmap_pic1);
        }else {
            Log.d("DJGJDGVJ",Picture);
            images.setVisibility(View.GONE);
            imageslide.setVisibility(View.VISIBLE);
            List<SlideModel> slideModels = new ArrayList<>();
            if (Picture.equals("") || Picture.equals("null")){
                slideModels.add(new SlideModel(R.drawable.camera,"รูปที่1"));
                //del_pic1.setVisibility(View.GONE);
            }else {
                //del_pic1.setVisibility(View.VISIBLE);
                slideModels.add(new SlideModel(Url+"images/uploads/"+Picture,"รูปที่1"));
            }
            if (Picture2.equals("") || Picture2.equals("null")){
                slideModels.add(new SlideModel(R.drawable.camera,"รูปที่2"));
                //del_pic1.setVisibility(View.GONE);
            }else {
                //del_pic1.setVisibility(View.VISIBLE);
                slideModels.add(new SlideModel(Url+"images/uploads/"+Picture2,"รูปที่2"));
            }
            if (Picture3.equals("") || Picture3.equals("null")){
                slideModels.add(new SlideModel(R.drawable.camera,"รูปที่3"));
                //del_pic1.setVisibility(View.GONE);
            }else {
                //del_pic1.setVisibility(View.VISIBLE);
                slideModels.add(new SlideModel(Url+"images/uploads/"+Picture3,"รูปที่3"));
            }
            imageslide.setImageList(slideModels,true);
        }
    }
}